# Geometry Rust

Mini juego original de saltos inspirado en los juegos de plataformas de ritmo. Incluye un nivel infinito sencillo, puntaje, récord local y controles de teclado o pantalla. Funciona sin conexión y no necesita instalar programas adicionales.

## Instalar en Windows

1. Extrae todos los archivos de la descarga.
2. Haz clic derecho en `Instalar-Geometry-Rust.ps1` y selecciona **Ejecutar con PowerShell**.
3. Abre **Geometry Rust** desde el menú Inicio.

Para quitarlo, ejecuta `Desinstalar-Geometry-Rust.ps1` con PowerShell.

Si Windows muestra una confirmación al abrir el script que descargaste, verifica que provenga de este proyecto y elige permitir su ejecución.

## Jugar

Pulsa **JUGAR** y salta con `Espacio`, `↑`, `W` o tocando/clicando el área del juego. Tu récord se guarda en este navegador.

## Archivos

- `index.html`: juego completo, sin dependencias externas.
- `Instalar-Geometry-Rust.ps1`: instala el juego y crea un acceso directo en el menú Inicio.
- `Desinstalar-Geometry-Rust.ps1`: quita el juego y el acceso directo.

Geometry Rust es un proyecto de fans independiente y no está afiliado a Geometry Dash ni a sus creadores.
