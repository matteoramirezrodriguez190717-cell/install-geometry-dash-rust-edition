$ErrorActionPreference = 'Stop'
$appName = 'Geometry Rust'
$installDir = Join-Path $env:LOCALAPPDATA 'GeometryRust'
$startMenuDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$shortcutPath = Join-Path $startMenuDir 'Geometry Rust.lnk'
$source = Join-Path $PSScriptRoot 'index.html'

if (-not (Test-Path -LiteralPath $source)) {
    Write-Error 'No se encontró index.html. Extrae la carpeta completa antes de instalar.'
    exit 1
}

New-Item -ItemType Directory -Path $installDir -Force | Out-Null
Copy-Item -LiteralPath $source -Destination (Join-Path $installDir 'index.html') -Force
New-Item -ItemType Directory -Path $startMenuDir -Force | Out-Null
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = Join-Path $env:SystemRoot 'explorer.exe'
$shortcut.Arguments = '"' + (Join-Path $installDir 'index.html') + '"'
$shortcut.WorkingDirectory = $installDir
$shortcut.Description = 'Juega Geometry Rust'
$shortcut.Save()
Write-Host 'Geometry Rust quedó instalado. Lo encontrarás en el menú Inicio.' -ForegroundColor Cyan
