@echo off
title Instalar Geometry Rust
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-Geometry-Rust.ps1"
if errorlevel 1 (
  echo.
  echo No se pudo instalar. Asegurate de extraer todos los archivos primero.
  pause
)
