$ErrorActionPreference = 'Stop'
$installDir = Join-Path $env:LOCALAPPDATA 'GeometryRust'
$shortcutPath = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Geometry Rust.lnk'
Remove-Item -LiteralPath $installDir -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $shortcutPath -Force -ErrorAction SilentlyContinue
Write-Host 'Geometry Rust se desinstaló.' -ForegroundColor Cyan
